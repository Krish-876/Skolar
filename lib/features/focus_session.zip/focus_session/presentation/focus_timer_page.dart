import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:nova/core/theme/app_theme.dart';
import 'package:nova/features/focus_session/data/models/focus_present.dart';
import 'package:nova/features/focus_session/widgets/present_chip.dart';

import '../controllers/focus_timer_controller.dart';
import '../widgets/focus_background.dart';
import 'focus_setup_page.dart';

class FocusTimerPage extends StatefulWidget {
  const FocusTimerPage({super.key});

  @override
  State<FocusTimerPage> createState() => FocusTimerPageState();
}

class FocusTimerPageState extends State<FocusTimerPage>
    with TickerProviderStateMixin {
  late final FocusTimerController _controller;
  bool _showGiveUpSheet = false;

  double _knobOffset = 0;
  bool _dragging = false;
  static const double _trackHorizontalPadding = 6.0;
  static const double _knobSize = 48.0;
  static const double _trackHeight = 62.0;
  static const double _triggerFraction = 0.82;

  @override
  void initState() {
    super.initState();
    _controller = FocusTimerController(vsync: this);
    _controller.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void showGiveUpSheet() {
    if (_controller.status == FocusTimerStatus.running) {
      setState(() => _showGiveUpSheet = true);
    }
  }

  double _maxKnobOffset(BoxConstraints constraints) {
    return constraints.maxWidth - _knobSize - (_trackHorizontalPadding * 2);
  }

  // Spring the wave back to 0 with elastic overshoot feel
  void _springWaveBack() {
    final spring = SpringDescription.withDampingRatio(
      mass: 1.0,
      stiffness: 180.0,
      ratio: 0.6, // underdamped → overshoot
    );
    final sim = SpringSimulation(
      spring,
      _controller.waveAnimationController.value, // from current position
      0.0,                                        // target: fully up
      -0.5,                                       // initial velocity (snapping back)
    );
    _controller.waveAnimationController.animateWith(sim);
  }

  // Spring the wave forward to 1.0 on trigger
  void _springWaveForward() {
    final spring = SpringDescription.withDampingRatio(
      mass: 1.0,
      stiffness: 300.0,
      ratio: 0.8, // slightly underdamped — quick snap with tiny settle
    );
    final sim = SpringSimulation(
      spring,
      _controller.waveAnimationController.value,
      1.0,
      2.0, // forward velocity
    );
    _controller.waveAnimationController.animateWith(sim);
  }

  @override
  Widget build(BuildContext context) {
    final isRunning = _controller.status == FocusTimerStatus.running;

    return PopScope(
      canPop: _controller.status == FocusTimerStatus.idle,
      onPopInvoked: (didPop) {
        if (!didPop && isRunning) showGiveUpSheet();
      },
      child: Scaffold(
        backgroundColor: AppTheme.background,
        body: Stack(
          children: [
            // Layer 0+1: Background glow + wave painter
            AnimatedBuilder(
              animation: _controller.waveAnimationController,
              builder: (context, _) {
                return FocusBackground(slideProgress: _controller.slideProgress);
              },
            ),

            // Layer 2: Main content
            SafeArea(
              child: Column(
                children: [
                  Expanded(
                    flex: 46,
                    child: _buildBonsaiHero(isRunning),
                  ),
                  Expanded(
                    flex: 54,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 28.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          _buildTimerReadout(),
                          const SizedBox(height: 40),
                          _buildInteractionZone(isIdle: !isRunning),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Layer 3: Give up sheet
            if (_showGiveUpSheet) _buildGiveUpOverlay(),
          ],
        ),
      ),
    );
  }

  Widget _buildBonsaiHero(bool isRunning) {
    return Center(
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
        padding: EdgeInsets.only(top: isRunning ? 40 : 0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.only(
    top: 10,    // ← push down
    left: 10,   // ← push right
  ),
              child: Image.asset(
                'assets/images/bonsai.png',
                width: 260,
                height: 240,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.spa_rounded,
                  size: 80,
                  color: Color.fromARGB(255, 77, 168, 59),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Focus time',
              style: TextStyle(
                color: Colors.white.withOpacity(isRunning ? 0.5 : 0.9),
                fontSize: 20,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimerReadout() {
    final isComplete = _controller.status == FocusTimerStatus.complete;
    return Text(
      isComplete ? 'Done!' : _controller.formattedTime,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 76,
        fontWeight: FontWeight.w700,
        letterSpacing: -1.5,
      ),
    );
  }

  Widget _buildInteractionZone({required bool isIdle}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedSize(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeInOut,
          child: isIdle
              ? Padding(
                  padding: const EdgeInsets.only(bottom: 20.0),
                  child: _buildPresetChipsRow(),
                )
              : const SizedBox.shrink(),
        ),
        LayoutBuilder(
          builder: (context, constraints) => _buildSliderTrackBar(constraints),
        ),
      ],
    );
  }

  Widget _buildPresetChipsRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ...List.generate(FocusPreset.defaults.length, (i) {
          final p = FocusPreset.defaults[i];
          final isActive = _controller.totalSeconds == p.seconds;
          return Padding(
            padding: const EdgeInsets.only(right: 6.0),
            child: PresetChip(
              label: p.label,
              isActive: isActive,
              onTap: () => _controller.setDuration(p.seconds),
            ),
          );
        }),
        PresetChip(
          label: 'Custom',
          isActive: false,
          icon: Icons.tune_rounded,
          onTap: () => _navigateToCustomSetupPage(),
        ),
      ],
    );
  }

  void _navigateToCustomSetupPage() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FocusSetupPage(
          initialSeconds: _controller.totalSeconds,
          onConfirm: (seconds) {
            _controller.setDuration(seconds);
            Navigator.pop(context);
          },
        ),
      ),
    );
  }

  Widget _buildSliderTrackBar(BoxConstraints constraints) {
    final isRunning = _controller.status == FocusTimerStatus.running;
    final maxOffset = _maxKnobOffset(constraints);

    return GestureDetector(
      onHorizontalDragStart: (_) => setState(() => _dragging = true),
      onHorizontalDragUpdate: (details) {
        setState(() {
          _knobOffset =
              (_knobOffset + details.delta.dx).clamp(0.0, maxOffset);
        });
        // 1:1 physical drag — surface follows knob exactly
        if (!isRunning) {
          _controller.waveAnimationController.value = _knobOffset / maxOffset;
        }
      },
      onHorizontalDragEnd: (_) {
        setState(() => _dragging = false);
        final progressFraction = _knobOffset / maxOffset;

        if (progressFraction >= _triggerFraction) {
          if (!isRunning) {
            // Spring wave fully down, then lock session
            setState(() => _knobOffset = maxOffset);
            _springWaveForward();
            Future.delayed(const Duration(milliseconds: 200), () {
              if (!mounted) return;
              _controller.start();
              setState(() => _knobOffset = 0);
            });
          } else {
            setState(() => _knobOffset = 0);
            showGiveUpSheet();
          }
        } else {
          // Released before threshold — elastic spring back
          setState(() => _knobOffset = 0);
          if (!isRunning) {
            _springWaveBack();
          }
        }
      },
      child: Container(
        height: _trackHeight,
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: isRunning
              ?const LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [
          AppTheme.primaryGradEnd, // ← left color
          AppTheme.bgGradEnd, // ← right color
        ],
      )
              : const LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [
                    Color(0xCCFFFFFF), // #FFFFFF 80%
                    AppTheme.surfaceGrad2End
                  ],
                  stops: [0.0, 0.81],
                ),
          borderRadius: BorderRadius.circular(_trackHeight / 2),
          border: Border.all(
            color: isRunning
                ?AppTheme.background
                : AppTheme.background,
            width: 1.0,
          ),
        ),
        child: Stack(
          alignment: Alignment.centerLeft,
          children: [
            Center(
              child: Text(
                isRunning ? 'Slide to give up' : 'Slide to lock in',
                style: TextStyle(
                  color: Colors.white.withOpacity(isRunning ? 0.6 : 0.4),
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            AnimatedPositioned(
              duration:
                  _dragging ? Duration.zero : const Duration(milliseconds: 200),
              curve: Curves.easeOutCubic,
              left: _trackHorizontalPadding + _knobOffset,
              child: Container(
                width: _knobSize,
                height: _knobSize,
                decoration: BoxDecoration(
                  color: isRunning
                      ? AppTheme.onBackground  
                      : AppTheme.background,  
                  shape: BoxShape.circle,
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 8,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: isRunning
                      ? AppTheme.background    // dark arrow on white knob
                      : AppTheme.onBackground, // white arrow on dark knob
                  size: 16,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGiveUpOverlay() {
    return Stack(
      children: [
        GestureDetector(
          onTap: () => setState(() => _showGiveUpSheet = false),
          child: Container(color: Colors.black.withOpacity(0.6)),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: _GiveUpSheetView(
            timeRemaining: _controller.formattedTime,
            onResume: () => setState(() => _showGiveUpSheet = false),
            onClear: () {
              setState(() => _showGiveUpSheet = false);
              _controller.reset();
            },
          ),
        ),
      ],
    );
  }
}

class _GiveUpSheetView extends StatelessWidget {
  final String timeRemaining;
  final VoidCallback onResume;
  final VoidCallback onClear;

  const _GiveUpSheetView({
    required this.timeRemaining,
    required this.onResume,
    required this.onClear,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
      decoration: const BoxDecoration(
        color: Color(0xFF0D1440),
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Give up this session?',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Remaining focus duration: $timeRemaining',
            style: const TextStyle(color: Colors.white60, fontSize: 14),
          ),
          const SizedBox(height: 28),
          ElevatedButton(
            onPressed: onResume,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1E2A8A),
              minimumSize: const Size(double.infinity, 50),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
            ),
            child: const Text(
              'Keep focusing',
              style: TextStyle(color: Colors.white),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: onClear,
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Colors.redAccent),
              minimumSize: const Size(double.infinity, 50),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
            ),
            child: const Text(
              'End session',
              style: TextStyle(color: Colors.redAccent),
            ),
          ),
        ],
      ),
    );
  }
}